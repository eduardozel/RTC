/*
**
**                           Main.c
**
**
**********************************************************************/
/*
   Last committed:     $Revision: 00 $
   Last changed by:    $Author: $
   Last changed date:  $Date:  $
   ID:                 $Id:  $

**********************************************************************/
#include <stm32f10x_conf.h>

#define RCC1_GPIO RCC_APB2Periph_GPIOA
#define RCC2_GPIO RCC_APB2Periph_GPIOB

#define LED_PORT GPIOB
#define LEDgrn_PIN GPIO_Pin_10
#define LEDred_PIN GPIO_Pin_11

#define BTNgrn_PORT GPIOA
#define BTNred_PORT GPIOB

#define BTNred_PIN GPIO_Pin_12
#define BTNgrn_PIN GPIO_Pin_8


void RTC_IRQHandler(void)
{
   if (RTC_GetITStatus(RTC_IT_SEC) != RESET)  {
     LED_PORT->ODR ^= LEDred_PIN;
     RTC_ClearITPendingBit(RTC_IT_SEC);
     RTC_WaitForLastTask();
   } else if (RTC_GetITStatus(RTC_IT_ALR )) {
     LED_PORT->ODR ^= LEDgrn_PIN;
     RTC_ClearITPendingBit(RTC_IT_ALR);
     RTC_WaitForLastTask();
     RTC_SetAlarm(RTC_GetCounter()+7);
   }
} // RTC_IRQHandler


void RTC_Config(void)
{
   NVIC_InitTypeDef NVIC_InitStructure;

/* Configure one bit for preemption priority */
//   NVIC_PriorityGroup Config(NVIC_PriorityGroup_1);

/* Enable the RTC Interrupt */
   NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
   NVIC_Init(&NVIC_InitStructure);

   RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

   PWR_BackupAccessCmd(ENABLE);
   RCC_LSEConfig(RCC_LSE_ON);
   while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET);
   RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
   RCC_RTCCLKCmd(ENABLE);


   RTC_WaitForSynchro();
   RTC_WaitForLastTask();
   RTC_ITConfig(RTC_IT_ALR | RTC_IT_SEC , ENABLE); // |
   RTC_WaitForLastTask();
   RTC_SetPrescaler(32767);

   RTC_WaitForLastTask();

} // RTC_Config

int main(void)
{
  RCC_APB2PeriphClockCmd(RCC1_GPIO, ENABLE);
  RCC_APB2PeriphClockCmd(RCC2_GPIO, ENABLE);

  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;

  GPIO_InitStructure.GPIO_Pin = LEDgrn_PIN | LEDred_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init( LED_PORT, &GPIO_InitStructure );

  GPIO_SetBits( LED_PORT, LEDred_PIN);
  RTC_Config();
  GPIO_SetBits( LED_PORT, LEDgrn_PIN);

  uint32_t tmp;

  tmp=RTC_GetCounter()+7;
  RTC_SetAlarm(tmp);
  while(1)
  {
  } // while
}
